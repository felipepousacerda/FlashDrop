package cl.flashdrop.orders.application.dto;

import java.math.BigDecimal;

/**
 * Resultado de la creación de un pedido.
 */
public record CreatedOrderResult(Long id, BigDecimal total) {}
