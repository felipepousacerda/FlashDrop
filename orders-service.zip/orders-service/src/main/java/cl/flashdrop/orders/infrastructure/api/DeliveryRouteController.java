package cl.flashdrop.orders.infrastructure.api;

import cl.flashdrop.orders.application.usecase.ClaimDeliveryOrdersUseCase;
import cl.flashdrop.orders.application.usecase.ListDeliveryRoutesUseCase;
import cl.flashdrop.orders.domain.model.Order;
import cl.flashdrop.orders.infrastructure.api.dto.request.ClaimDeliveryRequest;
import cl.flashdrop.orders.infrastructure.api.dto.response.ApiResponse;
import cl.flashdrop.orders.infrastructure.api.dto.response.DeliveryRouteResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Controlador REST para el dominio logístico de Reparto.
 *
 * Mapea los endpoints expuestos en '/api/delivery' respetando
 * la estructura de entrada y salida JSON del sistema original.
 */
@Slf4j
@RestController
@RequestMapping("/api/delivery")
@RequiredArgsConstructor
public class DeliveryRouteController {

    private final ListDeliveryRoutesUseCase listRoutesUseCase;
    private final ClaimDeliveryOrdersUseCase claimOrdersUseCase;

    @GetMapping("/routes")
    public ApiResponse<List<DeliveryRouteResponse>> listRoutes() {
        log.debug("GET /api/delivery/routes");
        List<Order> orders = listRoutesUseCase.execute();
        List<DeliveryRouteResponse> response = orders.stream()
                .map(this::toRouteResponse)
                .collect(Collectors.toList());
        return ApiResponse.success(response);
    }

    @PostMapping("/claim")
    public ApiResponse<Map<String, Object>> claimDeliveryOrders(@Valid @RequestBody ClaimDeliveryRequest request) {
        log.debug("POST /api/delivery/claim, userId={}, orderIds={}", request.getUserId(), request.getOrderIds());
        
        claimOrdersUseCase.execute(request.getUserId(), request.getOrderIds());
        
        // El endpoint original responde de esta forma:
        // success: true, message: 'Pedidos tomados. Tu ruta esta activa', data: { deliveryId, orderIds }
        // Para deliveryId, en esta etapa claimOrdersUseCase calcula/resuelve el deliveryId
        // pero podemos retornar un objeto estructurado que el frontend reconozca.
        Map<String, Object> responseData = Map.of(
                "userId", request.getUserId(),
                "orderIds", request.getOrderIds()
        );
        return ApiResponse.success("Pedidos tomados. Tu ruta esta activa", responseData);
    }

    // =========================================================================
    // Mappers
    // =========================================================================

    private DeliveryRouteResponse toRouteResponse(Order order) {
        var route = order.getRoute();
        String deliveryName = "";
        String deliveryPhone = "";
        Long deliveryId = null;
        Long deliveryUserId = null;

        if (order.getDeliveryInfo() != null) {
            deliveryName = order.getDeliveryInfo().fullName();
            deliveryPhone = order.getDeliveryInfo().getPhone();
            deliveryId = order.getDeliveryInfo().getDeliveryId();
            deliveryUserId = order.getDeliveryInfo().getUserId();
        }

        String clientName = order.getClientInfo() != null ? order.getClientInfo().fullName() : "Cliente";
        String clientPhone = order.getClientInfo() != null ? order.getClientInfo().getPhone() : "";
        String restaurantName = order.getRestaurantInfo() != null ? order.getRestaurantInfo().getName() : "";

        int itemCount = order.getItems().stream().mapToInt(item -> item.getQuantity()).sum();
        List<String> productNames = order.getItems().stream()
                .map(item -> item.getProductName())
                .collect(Collectors.toList());

        return DeliveryRouteResponse.builder()
                .id(route != null ? route.getId() : null)
                .orderId(order.getId())
                .code(order.code())
                .pickupAddress(route != null ? route.getPickupAddress() : "")
                .deliveryAddress(route != null ? route.getDeliveryAddress() : "")
                .distanceKm(route != null ? route.getDistanceKm() : java.math.BigDecimal.ZERO)
                .estimatedMinutes(route != null ? route.getEstimatedMinutes() : 0)
                .status(order.getStatus().getValue()) // order.status o route.status
                .restaurantName(restaurantName)
                .deliveryId(deliveryId)
                .deliveryUserId(deliveryUserId)
                .deliveryName(deliveryName)
                .deliveryPhone(deliveryPhone)
                .clientName(clientName)
                .clientPhone(clientPhone)
                .total(order.getTotal())
                .paymentMethod(order.getPaymentMethod().getValue())
                .itemCount(itemCount)
                .productNames(productNames)
                .createdAt(order.getCreatedAt())
                .build();
    }
}
