package cl.flashdrop.orders.infrastructure.api.dto.request;

import com.fasterxml.jackson.annotation.JsonAlias;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * DTO de entrada para que un repartidor tome pedidos.
 */
@Getter
@Setter
@NoArgsConstructor
public class ClaimDeliveryRequest {

    @NotNull(message = "El user_id es obligatorio")
    @JsonAlias("user_id")
    private Long userId;

    @NotEmpty(message = "Debes seleccionar al menos un pedido")
    @JsonAlias("order_ids")
    private List<Long> orderIds;
}
