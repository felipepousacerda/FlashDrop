package cl.flashdrop.orders.infrastructure.api.dto.response;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

/**
 * DTO para la respuesta de rutas de reparto activas.
 */
@Getter
@Builder
public class DeliveryRouteResponse {

    private final Long id;
    private final Long orderId;
    private final String code;
    private final String pickupAddress;
    private final String deliveryAddress;
    private final BigDecimal distanceKm;
    private final Integer estimatedMinutes;
    private final String status;
    private final String restaurantName;
    private final Long deliveryId;
    private final Long deliveryUserId;
    private final String deliveryName;
    private final String deliveryPhone;
    private final String clientName;
    private final String clientPhone;
    private final BigDecimal total;
    private final String paymentMethod;
    private final int itemCount;
    private final List<String> productNames;
    private final OffsetDateTime createdAt;
}
