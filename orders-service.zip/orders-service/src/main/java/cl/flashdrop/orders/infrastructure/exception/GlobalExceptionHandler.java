package cl.flashdrop.orders.infrastructure.exception;

import cl.flashdrop.orders.domain.exception.OrderDomainException;
import cl.flashdrop.orders.infrastructure.api.dto.response.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.stream.Collectors;

/**
 * Manejador global de excepciones para orders-service.
 *
 * Captura excepciones y genera respuestas con la estructura exacta:
 * {@code { success: false, message: "..." }}
 * mapeando el código de estado HTTP adecuado para coincidir con Node.js.
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(OrderDomainException.class)
    public ResponseEntity<ApiResponse<Void>> handleDomainException(OrderDomainException ex) {
        log.warn("Excepción de dominio de pedido capturada: {}", ex.getMessage());
        String msg = ex.getMessage();
        HttpStatus status = HttpStatus.BAD_REQUEST;

        // Mapeo dinámico de estados HTTP para coincidir con Node.js
        if (msg.contains("no encontrado") || msg.contains("no existen") || msg.contains("no disponibles")) {
            status = HttpStatus.NOT_FOUND;
        } else if (msg.contains("perfil de repartidor")) {
            status = HttpStatus.FORBIDDEN;
        } else if (msg.contains("ya tienes") || msg.contains("ya fueron tomados") || msg.contains("Alguien tomo")) {
            status = HttpStatus.CONFLICT;
        }

        return ResponseEntity.status(status)
                .body(ApiResponse.error(msg));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Void>> handleValidationException(MethodArgumentNotValidException ex) {
        String details = ex.getBindingResult().getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining(", "));
        log.warn("Error de validación de argumentos REST: {}", details);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ApiResponse.error(details));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Void>> handleGenericException(Exception ex) {
        log.error("Error no controlado capturado: ", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ApiResponse.error("Error interno del servidor: " + ex.getMessage()));
    }
}
