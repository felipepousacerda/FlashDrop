package cl.flashdrop.orders.application.usecase;

import cl.flashdrop.orders.domain.exception.OrderDomainException;
import cl.flashdrop.orders.domain.model.Order;
import cl.flashdrop.orders.domain.model.OrderStatus;
import cl.flashdrop.orders.domain.port.DeliveryPort;
import cl.flashdrop.orders.domain.port.OrderRepositoryPort;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ClaimDeliveryOrdersUseCaseTest {

    @Mock
    private OrderRepositoryPort orderRepository;
    @Mock
    private DeliveryPort deliveryPort;

    @InjectMocks
    private ClaimDeliveryOrdersUseCase claimDeliveryOrdersUseCase;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(claimDeliveryOrdersUseCase, "maxClaimPerRoute", 3);
    }

    @Test
    void shouldClaimOrdersSuccessfully() {
        Long userId = 1L;
        List<Long> orderIds = List.of(100L, 101L);

        when(deliveryPort.findDeliveryIdByUserId(userId)).thenReturn(Optional.of(5L));
        when(orderRepository.countActiveOrdersByDelivery(5L)).thenReturn(0);

        Order order1 = Order.builder().id(100L).restaurantId(10L).status(OrderStatus.NUEVO_PEDIDO).build();
        Order order2 = Order.builder().id(101L).restaurantId(10L).status(OrderStatus.NUEVO_PEDIDO).build();
        when(orderRepository.findByIdsForClaim(any())).thenReturn(List.of(order1, order2));

        when(orderRepository.claimOrders(any(), eq(5L), eq(OrderStatus.EN_CAMINO))).thenReturn(2);

        assertDoesNotThrow(() -> claimDeliveryOrdersUseCase.execute(userId, orderIds));

        verify(orderRepository).claimOrders(any(), eq(5L), eq(OrderStatus.EN_CAMINO));
        verify(orderRepository).updateRouteStatus(any(), eq("En camino"));
    }

    @Test
    void shouldThrowExceptionWhenClaimingTooManyOrders() {
        Long userId = 1L;
        List<Long> orderIds = List.of(100L, 101L, 102L, 103L); // 4 orders

        OrderDomainException exception = assertThrows(OrderDomainException.class,
                () -> claimDeliveryOrdersUseCase.execute(userId, orderIds));

        assertTrue(exception.getMessage().contains("Debes seleccionar entre 1 y 3 pedidos"));
        verifyNoInteractions(deliveryPort, orderRepository);
    }

    @Test
    void shouldThrowExceptionWhenDriverHasActiveOrders() {
        Long userId = 1L;
        List<Long> orderIds = List.of(100L);

        when(deliveryPort.findDeliveryIdByUserId(userId)).thenReturn(Optional.of(5L));
        when(orderRepository.countActiveOrdersByDelivery(5L)).thenReturn(1); // has active order

        OrderDomainException exception = assertThrows(OrderDomainException.class,
                () -> claimDeliveryOrdersUseCase.execute(userId, orderIds));

        assertTrue(exception.getMessage().contains("Ya tienes pedidos en ruta"));
        verify(orderRepository, never()).findByIdsForClaim(any());
    }

    @Test
    void shouldThrowExceptionWhenOrdersAreFromDifferentRestaurants() {
        Long userId = 1L;
        List<Long> orderIds = List.of(100L, 101L);

        when(deliveryPort.findDeliveryIdByUserId(userId)).thenReturn(Optional.of(5L));
        when(orderRepository.countActiveOrdersByDelivery(5L)).thenReturn(0);

        Order order1 = Order.builder().id(100L).restaurantId(10L).status(OrderStatus.NUEVO_PEDIDO).build();
        Order order2 = Order.builder().id(101L).restaurantId(20L).status(OrderStatus.NUEVO_PEDIDO).build(); // different restaurant
        when(orderRepository.findByIdsForClaim(any())).thenReturn(List.of(order1, order2));

        OrderDomainException exception = assertThrows(OrderDomainException.class,
                () -> claimDeliveryOrdersUseCase.execute(userId, orderIds));

        assertTrue(exception.getMessage().contains("Solo puedes agrupar pedidos del mismo restaurante"));
        verify(orderRepository, never()).claimOrders(any(), any(), any());
    }
}
