package cl.flashdrop.orders.domain.model;

import cl.flashdrop.orders.domain.exception.OrderDomainException;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OrderDomainTest {

    @Test
    void shouldValidateSingleRestaurantSuccessfully() {
        List<ProductInfo> products = List.of(
                ProductInfo.builder().id(1L).restaurantId(10L).price(BigDecimal.valueOf(1000)).build(),
                ProductInfo.builder().id(2L).restaurantId(10L).price(BigDecimal.valueOf(2000)).build()
        );

        assertDoesNotThrow(() -> Order.validateSingleRestaurant(products));
    }

    @Test
    void shouldThrowExceptionWhenProductsFromMultipleRestaurants() {
        List<ProductInfo> products = List.of(
                ProductInfo.builder().id(1L).restaurantId(10L).price(BigDecimal.valueOf(1000)).build(),
                ProductInfo.builder().id(2L).restaurantId(20L).price(BigDecimal.valueOf(2000)).build()
        );

        OrderDomainException exception = assertThrows(OrderDomainException.class,
                () -> Order.validateSingleRestaurant(products));
        assertEquals("El pedido debe contener productos de un mismo local", exception.getMessage());
    }

    @Test
    void shouldThrowExceptionWhenProductListIsEmpty() {
        assertThrows(OrderDomainException.class,
                () -> Order.validateSingleRestaurant(Collections.emptyList()));
    }

    @Test
    void shouldCalculateSubtotalCorrectly() {
        List<OrderItem> items = List.of(
                OrderItem.builder().productId(1L).quantity(2).unitPrice(BigDecimal.valueOf(1500))
                        .lineTotal(BigDecimal.valueOf(3000)).build(),
                OrderItem.builder().productId(2L).quantity(1).unitPrice(BigDecimal.valueOf(2500))
                        .lineTotal(BigDecimal.valueOf(2500)).build()
        );

        BigDecimal subtotal = Order.calculateSubtotal(items);
        assertEquals(0, BigDecimal.valueOf(5500).compareTo(subtotal));
    }

    @Test
    void shouldCalculateTotalCorrectly() {
        BigDecimal subtotal = BigDecimal.valueOf(5000);
        BigDecimal deliveryFee = BigDecimal.valueOf(2500);

        BigDecimal total = Order.calculateTotal(subtotal, deliveryFee);
        assertEquals(0, BigDecimal.valueOf(7500).compareTo(total));
    }

    @Test
    void shouldThrowExceptionOnStatusTransitionFromDelivered() {
        Order order = Order.builder()
                .status(OrderStatus.ENTREGADO)
                .build();

        assertThrows(OrderDomainException.class,
                () -> order.validateStatusTransition(OrderStatus.NUEVO_PEDIDO));
    }

    @Test
    void shouldAssignDeliveryAndChangeStatusToEnCamino() {
        Order order = Order.builder()
                .status(OrderStatus.NUEVO_PEDIDO)
                .build();

        order.assignDelivery(5L);

        assertEquals(5L, order.getDeliveryId());
        assertEquals(OrderStatus.EN_CAMINO, order.getStatus());
    }
}
